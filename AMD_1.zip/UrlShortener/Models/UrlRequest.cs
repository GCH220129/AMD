﻿using System.ComponentModel.DataAnnotations;

namespace UrlShortener.Models
{
    public class UrlRequest
    {
        [Required]
        [Url]
        public string OriginalUrl { get; set; }
    }
}

