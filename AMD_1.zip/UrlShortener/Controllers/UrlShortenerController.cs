﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UrlShortener.Data;
using UrlShortener.Models;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UrlShortener.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UrlShortenerController : ControllerBase
    {
        private readonly UrlShortenerContext _context;
        private readonly ILogger<UrlShortenerController> _logger;

        public UrlShortenerController(UrlShortenerContext context, ILogger<UrlShortenerController> logger)
        {
            _context = context;
            _logger = logger;
        }

        [HttpPost("shorten")]
        public async Task<IActionResult> ShortenUrl([FromBody] UrlRequest request)
        {
            if (request == null || string.IsNullOrEmpty(request.OriginalUrl))
            {
                return BadRequest("Invalid request.");
            }

            // Check for duplicate originalUrl
            var existingMapping = await _context.UrlMappings
                .FirstOrDefaultAsync(u => u.OriginalUrl == request.OriginalUrl);

            if (existingMapping != null)
            {
                return Conflict(new { message = "This URL has already been shortened." });
            }

            var urlMapping = new UrlMapping
            {
                OriginalUrl = request.OriginalUrl,
                ShortUrl = GenerateShortUrl(request.OriginalUrl), // Implement your short URL generation logic here
                CreatedAt = DateTime.UtcNow
            };

            _context.UrlMappings.Add(urlMapping);
            await _context.SaveChangesAsync();

            return Ok(new { ShortUrl = urlMapping.ShortUrl });
        }

        [HttpGet("{shortUrl}")]
        public async Task<IActionResult> GetOriginalUrl(string shortUrl)
        {
            var urlMapping = await _context.UrlMappings
                .FirstOrDefaultAsync(u => u.ShortUrl == shortUrl);

            if (urlMapping == null)
            {
                return NotFound();
            }

            return Redirect(urlMapping.OriginalUrl);
        }


        [HttpGet("list")]
        public async Task<IActionResult> GetShortenedUrls()
        {
            _logger.LogInformation("GetShortenedUrls called");

            var shortenedUrls = await _context.UrlMappings
                .Select(u => new { u.ShortUrl, u.OriginalUrl, u.CreatedAt })
                .ToListAsync();

            if (!shortenedUrls.Any())
            {
                _logger.LogWarning("No shortened URLs found.");
                return NotFound("No shortened URLs found.");
            }

            return Ok(shortenedUrls);
        }

        private string GenerateShortUrl(string originalUrl)
        {
            // Implement your short URL generation logic here
            return Convert.ToBase64String(Guid.NewGuid().ToByteArray())
                .Substring(0, 8);
        }
    }
}
