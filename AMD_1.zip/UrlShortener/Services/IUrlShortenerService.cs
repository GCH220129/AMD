﻿namespace UrlShortener.Services
{
    public interface IUrlShortenerService
    {
        string GenerateShortUrl(string originalUrl);
        string GetOriginalUrl(string shortUrl);
    }
}
