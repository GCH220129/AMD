﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Threading.Tasks;
using System.Xml.Serialization;
using UrlShortener.Controllers;
using UrlShortener.Data;
using UrlShortener.Models;
using UrlShortener.Services;
using Xunit;

namespace UrlShortener.Tests
{
    public class UrlShortenerTests : IDisposable
    {
        private readonly UrlShortenerContext _context;
        private readonly UrlShortenerController _controller;
        private readonly UrlShortenerService _service;
        private readonly Mock<ILogger<UrlShortenerController>> _logger;

        public UrlShortenerTests()
        {
            // Set up in-memory database
            var options = new DbContextOptionsBuilder<UrlShortenerContext>()
                .UseInMemoryDatabase(databaseName: "UrlShortenerTestDB")
                .Options;

            _context = new UrlShortenerContext(options);

            // Set up the mock logger
            _logger = new Mock<ILogger<UrlShortenerController>>();

            // Set up the service with the in-memory context
            _service = new UrlShortenerService(_context);

            // Set up the controller with the mock logger and service
            _controller = new UrlShortenerController(_context, _logger.Object);
        }

        [Fact]
        public async Task ShortenUrl_ValidRequest_ReturnsOkResult()
        {
            // Arrange
            var urlRequest = new UrlRequest { OriginalUrl = "https://www.example.com" };

            // Act
            var result = await _controller.ShortenUrl(urlRequest);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.NotNull(okResult.Value);

            var urlMapping = await _context.UrlMappings.FirstOrDefaultAsync();
            Assert.NotNull(urlMapping);
            Assert.Equal(urlRequest.OriginalUrl, urlMapping.OriginalUrl);
        }

        [Fact]
        public async Task ShortenUrl_NullRequest_ReturnsBadRequest()
        {
            // Act
            var result = await _controller.ShortenUrl(null);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal("Invalid request.", badRequestResult.Value);
        }

        [Fact]
        public async Task ShortenUrl_EmptyOriginalUrl_ReturnsBadRequest()
        {
            // Arrange
            var urlRequest = new UrlRequest { OriginalUrl = "" };

            // Act
            var result = await _controller.ShortenUrl(urlRequest);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal("Invalid request.", badRequestResult.Value);
        }

        [Fact]
        public async Task GetOriginalUrl_ValidShortUrl_ReturnsRedirectResult()
        {
            // Arrange
            var originalUrl = "https://www.example.com";
            var shortUrl = "abc12345";
            _context.UrlMappings.Add(new UrlMapping { OriginalUrl = originalUrl, ShortUrl = shortUrl });
            await _context.SaveChangesAsync();

            // Act
            var result = await _controller.GetOriginalUrl(shortUrl);

            // Assert
            var redirectResult = Assert.IsType<RedirectResult>(result);
            Assert.Equal(originalUrl, redirectResult.Url);
        }

        [Fact]
        public async Task GetOriginalUrl_InvalidShortUrl_ReturnsNotFound()
        {
            // Arrange
            var shortUrl = "invalid";

            // Act
            var result = await _controller.GetOriginalUrl(shortUrl);

            // Assert
            Assert.IsType<NotFoundResult>(result);
        }

        [Fact]
        public async Task ShortenUrlAsync_ValidRequest_ReturnsShortUrl()
        {
            // Arrange
            var originalUrl = "https://www.example.com";

            // Act
            var shortUrl = await _service.ShortenUrlAsync(originalUrl);

            // Assert
            var urlMapping = await _context.UrlMappings.FirstOrDefaultAsync();
            Assert.NotNull(urlMapping);
            Assert.Equal(originalUrl, urlMapping.OriginalUrl);
            Assert.Equal(shortUrl, urlMapping.ShortUrl);
        }

        [Fact]
        public async Task ResolveUrlAsync_ValidShortUrl_ReturnsOriginalUrl()
        {
            // Arrange
            var originalUrl = "https://www.example.com";
            var shortUrl = "abc12345";
            _context.UrlMappings.Add(new UrlMapping { OriginalUrl = originalUrl, ShortUrl = shortUrl });
            await _context.SaveChangesAsync();

            // Act
            var resolvedUrl = await _service.ResolveUrlAsync(shortUrl);

            // Assert
            Assert.Equal(originalUrl, resolvedUrl);
        }

        [Fact]
        public async Task ResolveUrlAsync_InvalidShortUrl_ReturnsNull()
        {
            // Arrange
            var shortUrl = "invalid";

            // Act
            var resolvedUrl = await _service.ResolveUrlAsync(shortUrl);

            // Assert
            Assert.Null(resolvedUrl);
        }

        public void Dispose()
        {
            // Dispose of in-memory database
            _context.Database.EnsureDeleted();
            _context.Dispose();
        }
    }
}

